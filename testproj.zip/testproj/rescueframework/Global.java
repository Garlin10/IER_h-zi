package rescueframework;

public class Global {
    public static int boxspeed;
}
