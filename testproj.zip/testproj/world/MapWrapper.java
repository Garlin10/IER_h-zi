package world;

import jason.asSyntax.Literal;
import rescueframework.RescueFramework;
import java.util.logging.Logger;

public class MapWrapper extends jason.environment.Environment{
	
	private Logger logger = Logger.getLogger("jasonTeamSimLocal.mas2j." + MapWrapper.class.getName());
	RescueFramework rf;
	
	public MapWrapper(){
		init();
	}
	
	public void init(){
		RescueFramework.main(null);
		rf = new RescueFramework();
		logger.info("asd");
	}
}